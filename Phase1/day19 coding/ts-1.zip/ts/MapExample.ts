const emp = new Map<number, string>(
[
    [101,"Niti"],
    [102,"Aditi"]
]);



for(const[id , name] of emp)
{
console.log(`id : ${id} , fname : ${name}`);
}