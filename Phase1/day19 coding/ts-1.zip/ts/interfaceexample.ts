interface Employee{

name : string;
age : number;

getDetails() : string;

}

class Hr implements Employee{
    name : string;
    age : number;

    constructor(name: string ,age: number){

        this.name = name
        this.age = age
    }
    id: number;
    
    getDetails() : string
    {

        return `Name : ${this.name} , Age : ${this.age}`;
    }

}

const obj = new Hr("Niti",30);
console.log(obj.getDetails())