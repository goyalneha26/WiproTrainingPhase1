//class is a blueprint for objects
// constructor is use to initialize the object
// Method -- 

class Employee
{
name : string;
id: number;

constructor(name:string , id:number)
{

    this.name = name;
    this.id = id;
}

getDetails(): string
{

return `Name: ${this.name}, id: ${this.id} `;
} 

}

// to create an object of a class



const obj1 =new Employee("Niti",101)
console.log(obj1.getDetails());