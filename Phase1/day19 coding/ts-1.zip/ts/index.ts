let num1:string="Type script example";  //global 
var a =10;

const value = "TypeScript";
function scopevariables()
{
let var1 : string = " Function level";
var a=10;

if(true)
{
     var a=20;
    
    let var2 : string ="Inside if block"; // Block Scope variable
    console.log("Block scope type of variable",var2);
    
}
let var2 : string ="some value";
console.log("Block scope type of variable",var2);
console.log("Global scope type of variable",num1);
console.log(var1);
}

scopevariables();