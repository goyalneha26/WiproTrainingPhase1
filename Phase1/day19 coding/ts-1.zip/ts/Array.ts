let empnames :string[] = ["Niti", "Aditi","Bhanu"];

console.log(empnames);

let empdata:[string , number , string] = ["Niti",101, "Trainer"];
console.log(empdata)