import logo from './logo.svg';
import './App.css';
import Counter from './components/Example1'
import Counter1 from './components/Example3'
import HW from './components/MainPageTheme'
import EX4 from './components/Example4'
import EX5 from './components/Example5'
import EX6 from './components/Example6'

function App() {
  return (
    <div>
      <EX6 />
    </div>
  );
}

export default App;
