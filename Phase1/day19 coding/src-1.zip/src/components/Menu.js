
import React  from "react";
class Menu extends React.Component
{
render()
{

    return(

<div>
    <a href ="/">Home</a>
    <a href ="/about">About Us</a>
    <a href ="/contact">Contact Us</a>
</div>

    );
}

}
export default Menu;