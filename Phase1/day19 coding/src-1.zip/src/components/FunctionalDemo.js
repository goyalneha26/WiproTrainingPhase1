
import Fdemo2 from './FunctionalDemo2';

import ClassComponent from '../classcomponents/ClassDemo1'
function Demo(props)
{



    return (
    
        <div>
        <ClassComponent />
         <h1>Heading of functional Component</h1>
        <h2>Hi ! {props.username} your department is : {props.dept}</h2>
        <h2> Functional Demo</h2>
        <Fdemo2 />
        </div>

    );
   
}

export default Demo;