
import './App.css';
import Fdemo from './components/FunctionalDemo';
import CDemo from './classcomponents/ClassDemo1';
import AboutUs from './components/AboutUs';
import ContactUs from './components/ContactUs';
import Home from './components/Home';
import NoMatch from './components/NoMatch';
import {Routes , Route} from 'react-router-dom';
import Menu from './components/Menu';

function App() {
  return (
    <>
    <Menu />
     <Routes>
          <Route path='/about' element={<AboutUs></AboutUs>}></Route>
          <Route path='/contact' element={<ContactUs></ContactUs>}></Route>
          <Route path='/' element={<Home></Home>}></Route>
          <Route path='*' element={<NoMatch></NoMatch>}></Route>
     </Routes>
    
    </>
   
  );
}
export default App;
