
import React from 'react';

class ClassDemo1 extends React.Component
{

    render()
    {

        return <h1> You have visited : {this.props.sitevisited}</h1>;
    }



}

export default ClassDemo1;